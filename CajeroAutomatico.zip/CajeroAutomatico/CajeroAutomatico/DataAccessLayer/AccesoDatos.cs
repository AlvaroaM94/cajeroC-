﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    class AccesoDatos
    {
        private static String cadenaConexion = @"Data Source=LAPTOP-BPKAPJHG\SQLEXPRESS;Database = BancoIbero;Integrated Security=True";

        public static String probar()
        {
            String mensaje = "Me conecte a la Base";
            SqlConnection miConexion = new SqlConnection(cadenaConexion);

            try
            {
                miConexion.Open();

            }catch(Exception ex)
            {
                mensaje = ex.Message;
            }
            finally
            {
                miConexion.Close();
            }


            return mensaje;

            
        }
    }
}
