﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CajeroAutomatico
{
    public partial class Bienvenido : Form
    {

        Tarjeta nuevaTarjeta;

        private void Bienvenido_Load(object sender, EventArgs e)
        {
           
            /*nuevaTarjeta = new Tarjeta(50001,"000","1234","VISA",DateTime.Parse("01-01-2025"),true);*/
            MessageBox.Show(AccesoDatos.probar());
        }

        public Bienvenido()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormNIP nuevaforma = new FormNIP();

            int tatjetaLeida;

            tatjetaLeida = int.Parse(textTarjeta.Text);//recibe el texto
            if(tatjetaLeida == nuevaTarjeta.noTarjeta)
            {
                if(nuevaTarjeta.estatus == true)
                {
                    this.Hide();
                    nuevaforma.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("Su tarjeta esta cancelada");
                }
            }
            else
            {
                MessageBox.Show("Numero de tarjeta invalido");
            }
            borrar();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            borrar();
        }

        private void borrar() {
            textTarjeta.Text = String.Empty;
            textTarjeta.Select();
        }
    }
}
