﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    public class Tarjeta
    {
        public int noTarjeta;
        public String cvv;
        private String nip;
        public String marca;
        public DateTime fechaExp;
        public bool estatus;

        Tarjeta()
        {
        }

        public Tarjeta(int noTarjeta,String cvv,String nip,String marca,DateTime fechaExp,bool estatus)
        {
            this.noTarjeta = noTarjeta;
            this.cvv = cvv;
            this.nip = nip;
            this.marca = marca;
            this.fechaExp = fechaExp;
            this.estatus = estatus;
        }

        public bool validarNip(String nipLeido)
        {
            bool bandera = false;
            if (nipLeido.Equals(nip))
                bandera = true;
            return bandera;
            
        }

        public void cancelarTarjeta()
        {
            estatus = false;
        }

    }
}
