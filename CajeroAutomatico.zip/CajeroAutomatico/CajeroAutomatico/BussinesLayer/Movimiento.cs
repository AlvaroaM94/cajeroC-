﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    public class Movimiento
    {
        int idMov;
        double depostito;
        double retiro;
        String descripcion;
        DateTime fechMov;

    }
}
