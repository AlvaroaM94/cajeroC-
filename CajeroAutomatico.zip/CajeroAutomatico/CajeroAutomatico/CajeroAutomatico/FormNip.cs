﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CajeroAutomatico
{
    public partial class FormNip : Form
    {
        private int contador = 0;
        public Tarjeta miTarjeta;
        public FormNip()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MenuPrincipal nuevoMenu = new MenuPrincipal();
            String nipLeido = textBox1.Text;
            contador++;
            if(miTarjeta.validarNip(nipLeido))
            {
                this.Hide();
                nuevoMenu.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Nip incorrecto");
                if(contador == 3)
                {
                    miTarjeta.cancelarTarjeta();
                    AccesoDato.cancelarTarjeta(miTarjeta.noTarjeta);
                    MessageBox.Show("Su tarjeta ha sido cancelada");
                    this.Close();
                }
            }
        }

        private void FormNip_Load(object sender, EventArgs e)
        {

        }
    }
}
