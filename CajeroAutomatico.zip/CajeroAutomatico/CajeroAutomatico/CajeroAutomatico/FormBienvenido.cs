﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CajeroAutomatico
{
    public partial class FormBienvenido : Form
    {
        Tarjeta nuevaTarjeta;
        private void FormBienvenido_Load(object sender, EventArgs e)
        {

            MessageBox.Show(AccesoDato.probar());
        }
        public FormBienvenido()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormNip nuevaForma = new FormNip();
            int tarjetaLeida = 0;



            try
            {
                tarjetaLeida = int.Parse(textTarjeta.Text);
                nuevaTarjeta = AccesoDato.consultarTarjeta(tarjetaLeida);
            }
            catch
            {
                MessageBox.Show("Error al leer tarjeta");
            }

            if (nuevaTarjeta != null)
            {
                if (tarjetaLeida == nuevaTarjeta.noTarjeta)
                {
                    if (nuevaTarjeta.estatus == true)
                    {
                        this.Hide();
                        nuevaForma.miTarjeta = nuevaTarjeta; //Paso el objeto Tarjeta a la nueva forma
                        nuevaForma.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        MessageBox.Show("Su tarjeta esta cancelada");
                    }
                }
                else
                {
                    MessageBox.Show("Numero de tarjeta invalido");
                }

            }
            else
            {
                MessageBox.Show("La tarjeta no existe");
            }
            borrar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            borrar();
        }

        void borrar()
        {
            textTarjeta.Text = String.Empty;
            textTarjeta.Select();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
