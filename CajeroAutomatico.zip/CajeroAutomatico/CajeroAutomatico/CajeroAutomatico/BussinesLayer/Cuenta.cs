﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    public class Cuenta
    {
        int noCuenta;
        double saldo;
        String moneda;
        String tipo;
        bool estatus;
        Tarjeta miTarjeta;
        List<Movimiento>misMovimientos;
    }
}
