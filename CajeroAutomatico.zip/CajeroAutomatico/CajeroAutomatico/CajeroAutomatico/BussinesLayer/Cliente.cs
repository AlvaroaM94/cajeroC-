﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    public class Cliente
    {
        int noCliente;
        String nombre;
        String apellidoP;
        String apellidoM;
        DateTime fechaNac;
        char sexo;
        List<Cuenta> misCuentas;

        Cliente()
        {
            misCuentas = new List<Cuenta>();
        }

        Cliente(String nombre, String apellidoP, String apellidoM):this()
        {
            this.nombre = nombre;
            this.apellidoP = apellidoP;
            this.apellidoM = apellidoM;
        }

        Cliente(String nombre, String apellidoP, String apellidoM, DateTime fechaNac):this(nombre, apellidoP, apellidoM)
        {
            this.fechaNac = fechaNac;
        }

        Cliente(String nombre, String apellidoP, String apellidoM, DateTime fechaNac, char sexo):this(nombre, apellidoP, apellidoM,fechaNac)
        {
            this.sexo = sexo;
        }

        public void agregarCuenta(Cuenta nuevaCuenta)
        {
            misCuentas.Add(nuevaCuenta);
        }
    }
}
