﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace CajeroAutomatico
{
    public static class AccesoDato
    {
        private static String cadenaConexion = @"Data Source=LAPTOP-M941AAAD\SQLEXPRESS;Database = BancoIbero;Integrated Security=True";
        
        public static String probar()
        {
            String mensaje = "Me conecte a la base";
            SqlConnection miConexion = new SqlConnection(cadenaConexion);

            try
            {
                miConexion.Open();
            }
            catch(Exception ex)
            {
                mensaje = ex.Message;
            }
            finally
            {
                miConexion.Close();
            }

            return mensaje;
        }

        public static Tarjeta consultarTarjeta(int numTarjeta)
        {
            Tarjeta tarjetita = null;
            SqlConnection miConexion = new SqlConnection(cadenaConexion);
            SqlCommand miComando = new SqlCommand();
            SqlDataReader miLector;
            SqlParameter paramTarjeta = new SqlParameter("@numTarjeta",System.Data.SqlDbType.Int);

            try
            {
                miConexion.Open();
                miComando.Connection = miConexion;
                miComando.CommandText = "SELECT * FROM Tarjetas WHERE NoTarjeta = @numTarjeta";
                paramTarjeta.Value = numTarjeta;
                miComando.Parameters.Add(paramTarjeta);
                miLector = miComando.ExecuteReader();

                while(miLector.Read())
                {
                    int noTarjeta = int.Parse(miLector[0].ToString());
                    String cvv = miLector[1].ToString();
                    String nip = miLector[2].ToString();
                    String marca = miLector[3].ToString();
                    DateTime fechaExp =DateTime.Parse( miLector[4].ToString());
                    bool estatus = bool.Parse(miLector[5].ToString());

                    tarjetita = new Tarjeta(noTarjeta,cvv,nip,marca,fechaExp,estatus);
                }
            }
            catch (Exception ex)
            {
               
            }
            finally
            {
                miConexion.Close();
            }

            
            return tarjetita;
        }

        public static bool cancelarTarjeta(int numTarjeta)
        {
            bool bandera = false;

            SqlConnection miConexion = new SqlConnection(cadenaConexion);
            SqlCommand miComando = new SqlCommand();
            SqlParameter paramTarjeta = new SqlParameter("@numTarjeta", System.Data.SqlDbType.Int);

            try
            {
                miConexion.Open();
                miComando.Connection = miConexion;
                miComando.CommandText = "UPDATE Tarjetas SET Estatus = 0 WHERE NoTarjeta =@numTarjeta";
                paramTarjeta.Value = numTarjeta;
                miComando.Parameters.Add(paramTarjeta);
                miComando.ExecuteNonQuery();
                bandera = true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                miConexion.Close();
            }
            return bandera;
        }

        public static Cuenta obtenerCuenta(int noTarjeta)
        {
            Cuenta miCuenta = null;
            SqlConnection miConexion = new SqlConnection(cadenaConexion);
            SqlCommand miComando = new SqlCommand();
            SqlDataAdapter miAdaptador = new SqlDataAdapter(miComando);
            SqlParameter paramTarjeta = new SqlParameter("@numTarjeta", System.Data.SqlDbType.Int);
            DataTable tablaCuenta = new DataTable();

            try
            {
                miConexion.Open();
                miComando.Connection = miConexion;
                miComando.CommandText = "SELECT CTA.* FROM Cuentas as CTA JOIN Tarjetas AS TAR ON CTA.NoCuenta = TAR.Cuenta  WHERE TAR.NoTarjeta =@numTarjeta";
                miComando.Parameters.Add(paramTarjeta);
                paramTarjeta.Value = noTarjeta;
                miAdaptador.Fill(tablaCuenta);

                if(tablaCuenta.Rows.Count > 0)
                {

                    int noCuenta = int.Parse(tablaCuenta.Rows[0].ItemArray[0].ToString());
                }
                   

            }
            catch
            {

            }
            finally
            {
                miConexion.Close();
            }



            return miCuenta;
        }

        public static Cliente obtenerCliente(int noCuenta)
        {
            Cliente miCliente = null;



            return miCliente;
        }
        public static List<Movimiento> obtenerMovimientos(int noCuenta)
        {
            List<Movimiento> misMovimientos = new List<Movimiento>();



            return misMovimientos;
        }
        public static bool depositar(int noCuenta, double monto, String descripcion)
        {
            bool bandera = true;

            return bandera;
        }
        public static bool retirar(int noCuenta, double monto, String descripcion)
        {
            bool bandera = true;

            return bandera;
        }

    }

}
